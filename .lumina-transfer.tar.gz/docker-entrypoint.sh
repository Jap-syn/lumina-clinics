#!/usr/bin/env sh
set -e

# APP_KEY must exist before anything boots; the consent records are encrypted
# with it, so on Railway set it once as a variable rather than regenerating.
if [ -z "$APP_KEY" ]; then
  echo "APP_KEY is not set. Generating an ephemeral one (encrypted consent"
  echo "records will not survive a redeploy - set APP_KEY in Railway)."
  php artisan key:generate --force
fi

php artisan migrate --force

# Seed only the first time, so a redeploy does not duplicate the branches.
php artisan db:seed --force --class="Database\\Seeders\\DatabaseSeeder" || \
  echo "Seed skipped (data already present)."

exec php artisan serve --host=0.0.0.0 --port="${PORT:-8080}"
