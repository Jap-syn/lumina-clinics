<?php

namespace App\Providers;

use App\Services\Payments\FakeGateway;
use App\Services\Payments\PaymentGateway;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Phase one runs against a stub. Swapping in a real provider (Omise and
        // 2C2P both fit Thai card + PromptPay) means one class and this binding.
        $this->app->singleton(PaymentGateway::class, FakeGateway::class);
    }

    public function boot(): void
    {
        // Catch a mistyped attribute in development rather than silently
        // writing nothing - money and times are involved.
        Model::preventSilentlyDiscardingAttributes(! app()->isProduction());
    }
}
