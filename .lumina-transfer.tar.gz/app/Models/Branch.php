<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Branch extends Model
{
    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'open_weekdays' => 'array',
        ];
    }

    public function rooms(): HasMany
    {
        return $this->hasMany(Room::class);
    }

    public function therapists(): HasMany
    {
        return $this->hasMany(Therapist::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    /** ISO-8601 weekday number, 1 = Monday. */
    public function opensOnWeekday(int $isoWeekday): bool
    {
        return in_array($isoWeekday, $this->open_weekdays, true);
    }
}
