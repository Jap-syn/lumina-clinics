<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Phase one guard for the reception diary.
 *
 * A single shared bearer token. This is deliberately thin and is listed in the
 * README under "Not done": per-user accounts with a role per branch are the
 * first thing to build in phase two, because the diary shows client contact
 * details and every receptionist would otherwise share one credential.
 */
class StaffToken
{
    public function handle(Request $request, Closure $next): Response
    {
        $supplied = $request->bearerToken() ?? $request->header('X-Staff-Token');

        if (! is_string($supplied) || ! hash_equals((string) config('lumina.staff_token'), $supplied)) {
            return response()->json(['error' => 'Staff authentication required.'], 401);
        }

        return $next($request);
    }
}
