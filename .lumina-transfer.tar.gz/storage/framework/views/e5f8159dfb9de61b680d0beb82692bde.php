<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Book at Lumina Clinics</title>
<style>
  :root { --line:#ddd; --ink:#1a1a1a; --muted:#666; --accent:#8a6a4f; }
  * { box-sizing:border-box; }
  body { font:16px/1.5 system-ui,-apple-system,Segoe UI,sans-serif; color:var(--ink);
         max-width:720px; margin:0 auto; padding:24px; }
  h1 { font-weight:600; letter-spacing:-.02em; }
  p.lede { color:var(--muted); }
  label { display:block; margin:14px 0 4px; font-size:14px; color:var(--muted); }
  select,input { width:100%; padding:9px 10px; border:1px solid var(--line); border-radius:6px; font:inherit; }
  .slots { display:flex; flex-wrap:wrap; gap:8px; margin-top:12px; }
  .slot { padding:8px 12px; border:1px solid var(--line); border-radius:6px; background:#fff; cursor:pointer; font:inherit; }
  .slot[aria-pressed="true"] { border-color:var(--accent); background:#faf6f2; }
  button.primary { margin-top:20px; padding:11px 18px; border:0; border-radius:6px;
                   background:var(--accent); color:#fff; font:inherit; cursor:pointer; }
  button.primary:disabled { opacity:.45; cursor:not-allowed; }
  .panel { border:1px solid var(--line); border-radius:8px; padding:16px; margin-top:20px; }
  .muted { color:var(--muted); font-size:14px; }
  .error { color:#a11; }
  .ok { color:#186a3b; }
  fieldset { border:1px solid var(--line); border-radius:8px; margin-top:16px; }
</style>
</head>
<body>
<h1>Book a treatment</h1>
<p class="lede">Phase one. Deliberately plain &mdash; the brief asks for working rules, not a finished interface.</p>

<label for="branch">Branch</label>
<select id="branch"></select>

<label for="treatment">Treatment</label>
<select id="treatment"></select>

<label for="therapist">Therapist</label>
<select id="therapist"><option value="">Anyone available</option></select>

<label for="date">Date</label>
<input type="date" id="date">

<div class="panel">
  <strong>Available times</strong>
  <div class="slots" id="slots"><span class="muted">Choose a branch, treatment and date.</span></div>
</div>

<fieldset>
  <legend class="muted">&nbsp;Your details&nbsp;</legend>
  <label for="name">Name</label>
  <input id="name" autocomplete="name">
  <label for="phone">Phone</label>
  <input id="phone" autocomplete="tel">
  <div id="consentBlock" style="display:none">
    <p class="muted">This treatment needs a signed consent record before we can book it.</p>
    <label for="nid">ID number</label>
    <input id="nid">
    <label for="dob">Date of birth</label>
    <input type="date" id="dob">
  </div>
</fieldset>

<button class="primary" id="go" disabled>Hold this time</button>
<div id="result" class="panel" style="display:none"></div>

<script>
const $ = id => document.getElementById(id);
let treatments = [], chosen = null;

// One key per checkout attempt, generated when the page loads. If the page
// hangs and the client presses pay again, the retry carries the same key and
// the server replays the first result instead of charging twice.
const idempotencyKey = 'web-' + Math.random().toString(36).slice(2) + Date.now();

const api = async (url, opts={}) => {
  const res = await fetch(url, opts);
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error || ('Request failed: ' + res.status));
  return body;
};

async function loadBranches() {
  const branches = await api('/api/branches');
  $('branch').innerHTML = branches.map(b => `<option value="${b.id}">${b.name}</option>`).join('');
  await loadTreatments();
}

async function loadTreatments() {
  treatments = await api('/api/treatments?branch_id=' + $('branch').value);
  $('treatment').innerHTML = treatments
    .map(t => `<option value="${t.id}">${t.name} &middot; ${t.duration_minutes} min</option>`).join('');
  await loadTherapists();
  onTreatmentChange();
}

async function loadTherapists() {
  const list = await api(`/api/therapists?branch_id=${$('branch').value}&treatment_id=${$('treatment').value}`);
  $('therapist').innerHTML = '<option value="">Anyone available</option>' +
    list.map(t => `<option value="${t.id}">${t.name}${t.title ? ' &middot; ' + t.title : ''}</option>`).join('');
}

function onTreatmentChange() {
  const t = treatments.find(x => x.id == $('treatment').value);
  $('consentBlock').style.display = t && t.requires_consent ? 'block' : 'none';
}

async function loadSlots() {
  chosen = null; $('go').disabled = true;
  if (!$('date').value) return;
  $('slots').innerHTML = '<span class="muted">Checking&hellip;</span>';
  try {
    const q = new URLSearchParams({
      branch_id: $('branch').value,
      treatment_id: $('treatment').value,
      date: $('date').value,
    });
    if ($('therapist').value) q.set('therapist_id', $('therapist').value);
    const data = await api('/api/availability?' + q);
    if (!data.slots.length) { $('slots').innerHTML = '<span class="muted">Nothing free that day.</span>'; return; }
    $('slots').innerHTML = '';
    data.slots.forEach(s => {
      const btn = document.createElement('button');
      btn.className = 'slot';
      btn.type = 'button';
      btn.setAttribute('aria-pressed', 'false');
      btn.textContent = new Date(s.starts_at)
        .toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
      btn.onclick = () => {
        chosen = s.starts_at;
        [...document.querySelectorAll('.slot')].forEach(b => b.setAttribute('aria-pressed', 'false'));
        btn.setAttribute('aria-pressed', 'true');
        $('go').disabled = false;
      };
      $('slots').appendChild(btn);
    });
  } catch (e) { $('slots').innerHTML = `<span class="error">${e.message}</span>`; }
}

$('go').onclick = async () => {
  $('go').disabled = true;
  const out = $('result');
  out.style.display = 'block';
  out.innerHTML = 'Holding the slot&hellip;';
  try {
    const payload = {
      branch_id: +$('branch').value,
      treatment_id: +$('treatment').value,
      starts_at: chosen,
      client: { name: $('name').value, phone: $('phone').value },
    };
    if ($('therapist').value) payload.therapist_id = +$('therapist').value;
    if ($('consentBlock').style.display === 'block') {
      payload.consent = { national_id: $('nid').value, date_of_birth: $('dob').value };
    }

    const booking = await api('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!booking.deposit.required) {
      out.innerHTML = `<p class="ok">Confirmed &mdash; <strong>${booking.reference}</strong></p>
        <p class="muted">No deposit: you are a member.</p>`;
      return;
    }

    out.innerHTML = `<p>Held as <strong>${booking.reference}</strong> until
      ${new Date(booking.hold_expires_at).toLocaleTimeString()}. Paying the deposit&hellip;</p>`;

    const paid = await api(`/api/bookings/${booking.reference}/deposit`, {
      method: 'POST',
      headers: { 'Accept': 'application/json', 'Idempotency-Key': idempotencyKey },
    });

    out.innerHTML = `<p class="ok">Confirmed &mdash; <strong>${paid.booking.reference}</strong></p>
      <p class="muted">Free cancellation until
      ${new Date(paid.booking.free_cancellation_until).toLocaleString()}.</p>`;
  } catch (e) {
    out.innerHTML = `<p class="error">${e.message}</p>`;
    $('go').disabled = false;
    loadSlots();
  }
};

$('branch').onchange = loadTreatments;
$('treatment').onchange = async () => { onTreatmentChange(); await loadTherapists(); loadSlots(); };
$('therapist').onchange = loadSlots;
$('date').onchange = loadSlots;

$('date').valueAsDate = new Date(Date.now() + 86400000);
loadBranches().then(loadSlots);
</script>
</body>
</html>
<?php /**PATH /Users/psa/Documents/custom/lumina/resources/views/book.blade.php ENDPATH**/ ?>