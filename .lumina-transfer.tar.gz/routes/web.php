<?php

use Illuminate\Support\Facades\Route;

// Two deliberately plain pages. The brief does not ask for a polished
// interface; these exist so the rules can be exercised by hand.
Route::view('/', 'book');
Route::view('/diary', 'diary');
